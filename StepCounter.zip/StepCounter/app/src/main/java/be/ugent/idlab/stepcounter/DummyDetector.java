package be.ugent.idlab.stepcounter;

public class DummyDetector implements IDetector {
    private int mSteps = 0;

    public void addAccelerationData(long timestamp, float x, float y, float z, DetectorLog log) {
        mSteps += 1;
    }

    public int getSteps() {
        return mSteps;
    }
}
